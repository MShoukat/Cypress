import { After, Before } from 'cypress-cucumber-preprocessor/steps'

Before({ tags: '@APIRequests' }, () => {
  cy.request({
    method : 'POST',
    url : '',
    body : {
        "wallet_address": 'abc_12345'
    },
    headers: {
        'content-type' : 'application/json'
    }
}).then((response) =>{
    expect(response.status).to.be.eq(201);
    expect(response.body.message).to.be.eq('Successfully Signup');
    var aut_token = response.body.auth_token;
    
})
})