import { Given } from "cypress-cucumber-preprocessor/steps";

Given ('I have the API endpoint', () => {
    let auth_token = '';
    // sending request to get the authorization token
    cy.request({
        method : 'POST',
        url : '',
        body : {
            "wallet_address": 'abc_1234589'
        },
        headers: {
            'content-type' : 'application/json'
        }
    }).then((response) =>{
        expect(response.status).to.be.eq(201);
        expect(response.body.message).to.be.eq('Successfully Signup');
         auth_token = response.body.auth_token;
        
    }).then(() => {
        cy.log('Bearer ' + auth_token);
        cy.request({
    
            method : 'POST',
            url : '',
            
            body : {
                'title':'test title',
                'description':'test description',
                'data-type':'image',
                'dataPool':'test'
                
            },
            headers: {
                'content-type' : 'application/json',
                'authorization': 'Bearer ' + auth_token
            }
            
        }).then((response) =>{
            expect(response.status).to.be.eq(201);
            
        })

    })
    

  
})
When ('I sent the request', () => {
    cy.log("Test Inprogress")
})
Then ('I see 201 in the status code', () => {
    cy.log("Test Passed")
})