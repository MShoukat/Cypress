
import { Given } from "cypress-cucumber-preprocessor/steps";

Given ('I have the API endpoint', () => {
    let auth_token = '';
    cy.request({
        method : 'POST',
        url : '',
        body : {
            "wallet_address": 'abc_12345'
        },
        headers: {
            'content-type' : 'application/json'
        }
    }).then((response) =>{
        expect(response.status).to.be.eq(201);
        expect(response.body.message).to.be.eq('Successfully Signup');
         auth_token = response.body.auth_token;
        
    })
    cy.log(auth_token);
    var data = new FormData();
    data.append("title", "test title");
    data.append("description", "test description");
    data.append("data_type", "image");
    data.append("dataPool", "djjjdj");
    data.append("data_files", fileInput.files[0], "/C:/Users/shokut.shah/Downloads/Faces/001_a.png");
    data.append("data_files", fileInput.files[0], "/C:/Users/shokut.shah/Downloads/Faces/001_b.png");

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if(this.readyState === 4) {
            console.log(this.responseText);
        }
    });
    
    

})

When ('I sent the request', () => {
    cy.log("Test Inprogress")
})
Then ('I see 201 in the status code', () => {
    cy.log("Test Passed")
})

        