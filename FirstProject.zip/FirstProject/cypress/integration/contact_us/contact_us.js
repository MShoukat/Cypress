import { Given } from "cypress-cucumber-preprocessor/steps";


Given ('I have API endpoint', () => {
    
})
When ('I have sent the request', () => {
    cy.request({
        method: 'POST',
        url: 'https://api-dev.nvg8.io/api/staticApp/contactUs',
        body: {
            "first_name": "M Anjum",
            "last_name": "Shah",
            "email": "mshoukat@gmail.com",
            "message": "Shoukat QA testing"
           
        },
        header: {
            'content-type': 'application/json'
        }
    })
    .then((response) => {
        expect(response.status).to.be.eq(201);
        expect(response.body.statusCode).to.eq(200);
        expect(response.body.message).to.be.eq('Data submitted successfully.');
    })
            
})
Then ('I see 201 in the status code', () => {
    cy.log("Test Passed")
})

//--------------- Get the data of user who contacted us.

Given ('I have the API endpoint', () => {
})
When ('I sent the request', () => {
    cy.request({
        method: 'GET',
        url: '',
        header: {
            'content-type': 'application/json'
        }
    })
    .then((response) => {
        var users = response.body.data;
        var length = users.length
        cy.log("Response is: ", response.body.data[length - 1].contact_us_id.first_name);
        cy.log("Response is: ", response.body.data[length - 1].contact_us_id.last_name);
        cy.log("Response is: ", response.body.data[length - 1].contact_us_id.email);
        cy.log("Response is: ", response.body.data[length - 1].message);  
       
    })
})
Then ('I get the data of user and see the status code 200', () => {
    cy.log("Test Passed")
})