import { Given } from "cypress-cucumber-preprocessor/steps";

Given ('I have the API endpoint', () => {
    var url = 'https://api-dev.nvg8.io/api/users/signup'
  cy.request({
      method : 'POST',
      url : 'https://api-dev.nvg8.io/api/users/signup',
      body : {
          "wallet_address": 'abc_12345'
      },
      headers: {
          'content-type' : 'application/json'
      }
  }).then((response) =>{
      expect(response.status).to.be.eq(201);
      var auth_token = response.body.auth_token;
      cy.log("Auth Token:", auth_token);
      expect(response.body.message).to.be.eq('Successfully Signup');
  })
})
When ('I sent the request', () => {
    cy.log("Test Inprogress")
})
Then ('I see 201 in the status code', () => {
    cy.log("Test Passed")
})